//Declarar uma variavel com o seu nome

var nome ="Patryck";

//Declarar uma variavel com a sua idade

var idade = '18';

//Declarar uma variavel com o seu filme favorito

var filmeFavorito = 'Homem de Ferro';

console.log (nome, idade, filmeFavorito)

//Declarar a variavel comida favorita 

//Não Atribuir valor

var comidaFavorita;


//Dar valor a comida favorita

comidaFavorita = 'Pastel';

console.log (comidaFavorita)

//Declarar 5 variaveis diferentes sem valor

var leao,
papagaio,
cachorro,
cavalo,
gato;

//Declarar 2 variaveis diferentes com valores

var nomeIrma = 'Laila'
var nomeMae = 'Mari'

console.log(nomeIrma, nomeMae, leao, papagaio, cavalo, cachorro, gato);