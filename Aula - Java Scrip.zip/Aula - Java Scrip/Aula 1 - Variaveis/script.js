var nome = 'Patryck'
var idade = 18
var possuiFaculdade = false;

console.log (nome, idade, possuiFaculdade);

/* Comentarios para uma grande quantidade de texto */

var preco = 25;
var totalComprado = 5;
var totalPreco = totalComprado * preco;

console.log (totalPreco)

//Podemos criar varias variaveis , sem repetir a palavra var. é só acrescentar a virgula

var sobrenome ="Bruno", 
    cidade = "Rio";

console.log (sobrenome, cidade);

//Hoisting - As variaveis são movidas para cima do codigo, porem o valor atribuido não e movido,

comida = 'Coxinha';
console.log(comida);

/* Mudar Valor atribuido - é possivel mudar os valores atribuidos a variaveis declaradas com Var.
Porem não é possivel modificar valores das declaradas com CONST.*/

var time = 'Botafogo';
time = 'Vasco';
console.log(time)