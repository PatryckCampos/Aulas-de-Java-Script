//tipos de dados

/* 

var nome = 'Patryck'; //string
var idade = 18; // Number
var possuiFaculdade = false; // Boolean
var time; // Undefined
var comida = null; // Null
var simbolo = Symbol() // Symbol
var novoObjeto = {} // Object



*/



//Verificando os tipos de dados


var nome = 'Patryck'; // String
console.log(typeof nome);
// retona String



var idade = 18; // Number
console.log(typeof idade);
// retona Number


var possuiFaculdade = false; // Boolean
console.log(typeof possuiFaculdade);
// retorna boolean


var time; // Undefined - Não foi atribuido valor a variavel
console.log(typeof time);
// retorna Undefined


var comida = null; // Null
console.log(typeof comida);
// retorna Null


var simbolo = Symbol() // Symbol
console.log(typeof simbolo);
// retorna Symbol


var novoObjeto = {} //Object
console.log(typeof novoObjeto);
// retorna Object